#!/usr/bin/env bash
# Build the independent checked CLI. Frozen83/34 source and binaries are inputs.
set -eo pipefail
project83_root=/home/lyh/ddt_ros2_ws
project83_work=/home/lyh/project83_work_20261104
project83_parent_plan=$project83_root/docs/experiments83/runtime83_preregistered.json
project83_build=$project83_work/build_runtime83_checked_01
rtk proxy /usr/bin/python3 - "$project83_parent_plan" "$project83_build" <<'PY'
import hashlib, json, os, sys
from pathlib import Path
def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1048576), b''): h.update(block)
    return h.hexdigest()
parent_plan, build = map(Path, sys.argv[1:])
parent = json.loads(parent_plan.read_text())
sources = dict(parent['source_sha256'])
for path, expected in sources.items():
    if sha(path) != expected: raise RuntimeError('frozen parent input changed: ' + path)
root = Path('/home/lyh/ddt_ros2_ws'); work = build.parent
new_inputs = [root/p for p in ('runtime83/cli83.hpp', 'runtime83/ros_checked83.cpp',
                              'runtime83/checked/CMakeLists.txt', 'tests/native/cli83_test.cpp',
                              'tests/test_cli83.py')]
new_inputs += [work/'build_checked83.sh', work/'run_ros_checked83.sh', parent_plan]
for path in new_inputs: sources[str(path)] = sha(path)
build.mkdir(exist_ok=False)
with (build/'initial_incomplete.json').open('x') as f:
    json.dump({'schema':'d1-runtime83-checked-build-v1','status':'INCOMPLETE',
               'parent_plan_sha256':sha(parent_plan),'source_sha256':sources,
               'actual_actor_calls':0,'physics_steps':0}, f, indent=2, sort_keys=True)
    f.write('\n'); f.flush(); os.fsync(f.fileno())
PY
source /opt/ros/humble/setup.bash
set -u
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export NUMEXPR_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 CMAKE_BUILD_PARALLEL_LEVEL=1
rtk proxy /usr/bin/cmake -S "$project83_root/runtime83/checked" -B "$project83_build" \
  -G 'Unix Makefiles' -DCMAKE_MAKE_PROGRAM=/usr/bin/make \
  -DCMAKE_CXX_COMPILER=/usr/bin/x86_64-linux-gnu-g++-11 \
  -DCMAKE_BUILD_TYPE=Release '-DCMAKE_CXX_FLAGS_RELEASE=-O1 -DNDEBUG'
rtk proxy /usr/bin/cmake --build "$project83_build" --parallel 1
rtk proxy /usr/bin/python3 - "$project83_parent_plan" "$project83_build" <<'PY'
import hashlib, json, os, shlex, sys
from pathlib import Path
def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1048576), b''): h.update(block)
    return h.hexdigest()
parent_plan, build = map(Path, sys.argv[1:])
initial = json.loads((build/'initial_incomplete.json').read_text())
if sha(parent_plan) != initial['parent_plan_sha256']: raise RuntimeError('parent plan changed')
for path, expected in initial['source_sha256'].items():
    if sha(path) != expected: raise RuntimeError('build input changed: ' + path)
dependencies = {}
for path in sorted(build.rglob('*.o.d')):
    for token in shlex.split(path.read_text().replace('\\\n',' ').partition(':')[2]):
        dependency = Path(token)
        if not dependency.is_absolute(): dependency = build/dependency
        dependencies[str(dependency.resolve())] = sha(dependency)
if not dependencies: raise RuntimeError('no actual compiler dependency files')
artifacts = [build/'ros_checked83', build/'CMakeCache.txt']
artifacts += sorted(build.rglob('flags.make')) + sorted(build.rglob('link.txt'))
receipt = dict(initial, status='COMPLETE', verification_after='COMPLETE',
               artifact_sha256={str(p):sha(p) for p in artifacts},
               observed_compiler_dependency_sha256=dependencies,
               optimization='-O1 -DNDEBUG', parallel_jobs=1,
               scope='Build only. No actor/ROS invocation; preregister real checked entry after cold validation.')
with (build/'build_receipt.json').open('x') as f:
    json.dump(receipt, f, indent=2, sort_keys=True)
    f.write('\n'); f.flush(); os.fsync(f.fileno())
print(json.dumps({'status':'COMPLETE','build':str(build),'actual_actor_calls':0}))
PY
