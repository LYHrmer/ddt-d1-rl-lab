"""Bind the independently repaired cold entry after real-binary validation."""
import copy
import hashlib
import json
from pathlib import Path

root=Path('/home/lyh/ddt_ros2_ws'); work=Path('/home/lyh/project83_work_20261104')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
old=root/'docs/experiments83/runtime83_preregistered.json'
assert sha(old)=='437fcda05945ece13549f210760a66fecceec84318938472d62441d9804dcd3d'
build=work/'build_runtime83_checked_01/build_receipt.json'
receipt=json.loads(build.read_text());cold=work/'cold_runtime_checked83.json'
c=json.loads(cold.read_text())
assert receipt['status']==receipt['verification_after']=='COMPLETE'
assert c['status']=='PASS' and len(c['valid_cases'])==4 and c['unknown_eighth_pair_rejected']
assert sha(work/'build_runtime83_checked_01/ros_checked83')==c['actual_binary_sha256']
for case in c['valid_cases']:
    r=case['receipt']
    assert r['status']=='COMPLETE' and r['option_pairs']==7 and r['validation_only']
    assert r['actor_calls']==r['model_calls']==r['physics_steps']==0
    assert not r['ros_initialized'] and not r['output_created']
source=root/'runtime83/ros_probe83.cpp'; checked=root/'runtime83/ros_checked83.cpp'
suffix='    fs::copy_file(manifest,output/"manifest.json");'
assert source.read_text().split(suffix,1)[1]==checked.read_text().split(suffix,1)[1]
plan=copy.deepcopy(json.loads(old.read_text()))
plan.update(schema='d1-runtime83-checked-preregistered-v1',parent_plan_sha256=sha(old),
    changes='Independent argv contract repair; original runtime body from manifest copy onward byte-identical',
    first_ros_attempt={'status':'INCOMPLETE','rpc_attempts':0,'ros_contexts':0,
        'evidence':str(work/'ros_nominal01'),'remaining_original_modes':'NOT_STARTED'},
    already_completed_native_requests=64,native_repeat_authorized=False,
    cold_validation_sha256=sha(cold),source_sha256=receipt['source_sha256'])
for p in (old,build,cold,work/'cold_ros_checked83.py',work/'revision83_engineering.md',Path(__file__)):
    plan['source_sha256'][str(p)]=sha(p)
plan['ros']['script']=str(work/'run_ros_checked83.sh')
plan['ros']['units']='Four new exclusive checked-entry units, serial, no repeated mode; 15s child wall/7s CPU each'
for mode,case in plan['ros']['cases'].items():
    case['manifest']=str(work/('runtime83_checked_ros_'+mode+'_manifest.json'))
    case['output']=str(root/'evidence/runtime83/execution_checked_01'/('ros_'+mode))
    assert not Path(case['manifest']).exists() and not Path(case['output']).exists()
for name,digest in plan['source_sha256'].items():assert sha(Path(name))==digest,name
target=root/'docs/experiments83/runtime83_checked_preregistered.json'
with target.open('x') as f:json.dump(plan,f,indent=2,sort_keys=True);f.write('\n')
print(json.dumps({'status':'SEALED','plan':str(target),'sha256':sha(target),'sources':len(plan['source_sha256'])}))
