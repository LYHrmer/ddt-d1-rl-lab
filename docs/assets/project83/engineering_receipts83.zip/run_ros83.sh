#!/usr/bin/env bash
# One fixed scenario only; no retry and no actuator/control-manager topics.
set -eo pipefail
if [[ $# != 1 ]]; then
  rtk proxy /usr/bin/printf '%s\n' 'usage: run_ros83.sh nominal|late_receive|late_response|stale_command' >&2
  exit 2
fi
project83_mode=$1
case "$project83_mode" in
  nominal) project83_ticks=24 ;;
  late_receive|late_response|stale_command) project83_ticks=1 ;;
  *) rtk proxy /usr/bin/printf '%s\n' 'unregistered runtime83 mode' >&2; exit 2 ;;
esac
project83_root=/home/lyh/ddt_ros2_ws
project83_work=/home/lyh/project83_work_20261104
project83_plan=$project83_root/docs/experiments83/runtime83_preregistered.json
project83_build=$project83_work/build_runtime83_01
project83_manifest=$project83_work/runtime83_ros_${project83_mode}_manifest.json
project83_output=$project83_root/evidence/runtime83/execution_01/ros_${project83_mode}

rtk proxy /usr/bin/python3 - "$project83_plan" "$project83_build" "$project83_mode" <<'PY'
import hashlib, json, os, sys
from pathlib import Path
def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1048576), b''): h.update(block)
    return h.hexdigest()
plan_path, build, mode = Path(sys.argv[1]), Path(sys.argv[2]), sys.argv[3]
plan = json.loads(plan_path.read_text())
receipt = json.loads((build/'build_receipt.json').read_text())
if receipt['status'] != 'COMPLETE' or receipt['verification_after'] != 'COMPLETE':
    raise RuntimeError('build is incomplete')
if sha(plan_path) != receipt['plan_sha256']: raise RuntimeError('plan differs from built source')
if receipt['source_sha256'] != plan['source_sha256']: raise RuntimeError('build source closure differs')
for mapping in (plan['source_sha256'], receipt['artifact_sha256'],
                receipt['observed_compiler_dependency_sha256']):
    for path, expected in mapping.items():
        if sha(path) != expected: raise RuntimeError('sealed input/artifact changed: ' + path)
case = plan['ros']['cases'][mode]
output = Path(case['output'])
if output.exists(): raise RuntimeError('scenario output already exists')
output.parent.mkdir(parents=True, exist_ok=True)
manifest = json.loads(Path(plan['native']['manifest']).read_text())
manifest['max_requests'] = 30
blob = (json.dumps(manifest, indent=2, sort_keys=True)+'\n').encode()
if hashlib.sha256(blob).hexdigest() != plan['ros']['derived_manifest_sha256']:
    raise RuntimeError('ROS manifest derivation mismatch')
with Path(case['manifest']).open('xb') as f:
    f.write(blob); f.flush(); os.fsync(f.fileno())
PY

# The Humble setup is a shell builtin exception to the rtk command prefix.
source /opt/ros/humble/setup.bash
set -u
export ROS_LOCALHOST_ONLY=1 ROS_DOMAIN_ID=183
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export NUMEXPR_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1
project83_return=0
rtk proxy "$project83_build/ros_probe83" --execute-synthetic-ros true \
  --manifest "$project83_manifest" --output "$project83_output" \
  --domain 183 --namespace "/adapter83/project83_${project83_mode}" \
  --ticks "$project83_ticks" --mode "$project83_mode" || project83_return=$?
rtk proxy /usr/bin/python3 - "$project83_plan" "$project83_output" "$project83_return" <<'PY'
import hashlib, json, sys
from pathlib import Path
plan = json.loads(Path(sys.argv[1]).read_text())
for path, expected in plan['source_sha256'].items():
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1048576), b''): h.update(block)
    if h.hexdigest() != expected: raise RuntimeError('source changed after DDS scenario: ' + path)
report = json.loads((Path(sys.argv[2])/'report.json').read_text())
if int(sys.argv[3]) == 0 and (report['status'] != 'COMPLETE' or report.get('verification_after') != 'COMPLETE'):
    raise RuntimeError('scenario incomplete; preserve all output')
print(json.dumps({'scenario_status':report['status'],'runtime_status':report['runtime_status'],
                  'runtime_accepted':report['runtime_accepted']}))
PY
exit "$project83_return"
