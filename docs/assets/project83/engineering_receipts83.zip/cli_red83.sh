#!/usr/bin/env bash
set -euo pipefail
rtk proxy mkdir /home/lyh/project83_work_20261104/cli_red_build01
rtk proxy /usr/bin/c++ -std=c++17 -O1 -Wall -Wextra -Werror -pedantic -DADAPTER83_CLI_LEGACY_SOURCE_ONLY /home/lyh/ddt_ros2_ws/tests/native/cli83_test.cpp -o /home/lyh/project83_work_20261104/cli_red_build01/cli83_red
rtk proxy /home/lyh/project83_work_20261104/cli_red_build01/cli83_red /home/lyh/ddt_ros2_ws/runtime83/ros_probe83.cpp
