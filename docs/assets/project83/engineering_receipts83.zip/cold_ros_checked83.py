"""Exercise the actual linked entry point without an actor or DDS context."""
import hashlib
import json
import subprocess
from pathlib import Path

work=Path('/home/lyh/project83_work_20261104')
root=Path('/home/lyh/ddt_ros2_ws')
binary=work/'build_runtime83_checked_01/ros_checked83'
results=[]
for mode in ('nominal','late_receive','late_response','stale_command'):
    out=root/'evidence/runtime83/execution_checked_01'/('ros_'+mode)
    assert not out.exists()
    args=[str(binary),'--validate-only','--execute-synthetic-ros','true',
          '--manifest',str(work/('runtime83_checked_ros_'+mode+'_manifest.json')),
          '--output',str(out),'--domain','183','--namespace','/adapter83/project83_'+mode,
          '--ticks','24' if mode=='nominal' else '1','--mode',mode]
    result=subprocess.run(['rtk','proxy',*args],capture_output=True,text=True,timeout=5)
    assert result.returncode==0,(mode,result.stdout,result.stderr)
    row=json.loads(result.stdout)
    assert not out.exists(),mode
    results.append({'mode':mode,'command':args,'returncode':result.returncode,'receipt':row})
bad=subprocess.run(['rtk','proxy',*args,'--unexpected','true'],capture_output=True,text=True,timeout=5)
assert bad.returncode!=0
receipt={'status':'PASS','actual_binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),
         'valid_cases':results,'unknown_eighth_pair_rejected':True,'bad_stdout':bad.stdout,'bad_stderr':bad.stderr,
         'new_model_calls':0,'new_actor_processes':0,'new_physics_steps':0,'new_ros_contexts':0}
with (work/'cold_runtime_checked83.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps({'status':'PASS','actual_valid_cli_cases':4,'invalid_extra_pair_rejected':True}))
