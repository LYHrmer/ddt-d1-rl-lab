import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path('/home/lyh/ddt_ros2_ws')
output = Path('/home/lyh/project83_work_20261104/vendor_dependency_receipt83.json')
if output.exists():
    raise FileExistsError(output)
deps = subprocess.run(['c++', '-std=c++17', '-M', '-I', str(root),
                       str(root/'runtime83/probe83.cpp')], capture_output=True, text=True, check=True)
paths = [Path(x) for x in deps.stdout.replace('\\\n', ' ').split() if '/nlohmann/' in x]
assert len(set(paths)) == 41
assert all(p.is_relative_to(root/'nlohmann') for p in paths)
assert all(p.read_bytes() == (Path('/usr/include')/p.relative_to(root)).read_bytes() for p in paths)
test = subprocess.run([sys.executable, '-B', '-m', 'pytest', '--noconftest',
                       'tests/test_adapter83.py', '-q', '-s'], cwd=root,
                      capture_output=True, text=True, timeout=60)
print(test.stdout, end='')
print(test.stderr, file=sys.stderr, end='')
receipt = {'status': 'PASS' if test.returncode == 0 else 'FAIL',
           'selected_vendor_headers': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(set(paths))},
           'equal_to_original_build_system_headers': True,
           'test_returncode': test.returncode, 'test_stdout': test.stdout, 'test_stderr': test.stderr,
           'actual_actor_calls': 0, 'physics_steps': 0, 'model_calls': 0}
with output.open('x') as f:
    json.dump(receipt, f, indent=2)
    f.write('\n')
raise SystemExit(test.returncode)
