#!/usr/bin/env bash
# Compile new83 only. Run once inside the root-owned bounded systemd unit.
set -eo pipefail
project83_root=/home/lyh/ddt_ros2_ws
project83_work=/home/lyh/project83_work_20261104
project83_plan=$project83_root/docs/experiments83/runtime83_preregistered.json
project83_build=$project83_work/build_runtime83_01

rtk proxy /usr/bin/python3 - "$project83_plan" "$project83_build" <<'PY'
import hashlib, json, os, sys
from pathlib import Path
def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1048576), b''): h.update(block)
    return h.hexdigest()
plan_path, build = map(Path, sys.argv[1:])
plan = json.loads(plan_path.read_text())
for path, expected in plan['source_sha256'].items():
    if sha(path) != expected: raise RuntimeError('sealed source changed: ' + path)
build.mkdir(exist_ok=False)
with (build/'initial_incomplete.json').open('x') as f:
    json.dump({'schema':'d1-runtime83-build-v1','status':'INCOMPLETE',
               'plan_sha256':sha(plan_path),'source_bindings':len(plan['source_sha256']),
               'actual_actor_calls':0,'physics_steps':0}, f, indent=2)
    f.write('\n'); f.flush(); os.fsync(f.fileno())
PY

# Full vendor environment setup requires shell source; no workspace overlay.
source /opt/ros/humble/setup.bash
set -u
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export NUMEXPR_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 CMAKE_BUILD_PARALLEL_LEVEL=1
rtk proxy /usr/bin/cmake -S "$project83_root/runtime83" -B "$project83_build" \
  -G 'Unix Makefiles' -DCMAKE_MAKE_PROGRAM=/usr/bin/make \
  -DCMAKE_CXX_COMPILER=/usr/bin/x86_64-linux-gnu-g++-11 \
  -DCMAKE_BUILD_TYPE=Release '-DCMAKE_CXX_FLAGS_RELEASE=-O1 -DNDEBUG' \
  -DADAPTER83_WITH_ROS=ON
rtk proxy /usr/bin/cmake --build "$project83_build" --parallel 1
rtk proxy /usr/bin/python3 - "$project83_plan" "$project83_build" <<'PY'
import hashlib, json, os, shlex, sys
from pathlib import Path
def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1048576), b''): h.update(block)
    return h.hexdigest()
plan_path, build = map(Path, sys.argv[1:])
plan = json.loads(plan_path.read_text())
initial = json.loads((build/'initial_incomplete.json').read_text())
if sha(plan_path) != initial['plan_sha256']: raise RuntimeError('plan changed during build')
for path, expected in plan['source_sha256'].items():
    if sha(path) != expected: raise RuntimeError('sealed source changed: ' + path)
dependencies = {}
for path in sorted(build.rglob('*.o.d')):
    for token in shlex.split(path.read_text().replace('\\\n',' ').partition(':')[2]):
        dependency = Path(token)
        if not dependency.is_absolute(): dependency = build/dependency
        dependencies[str(dependency.resolve())] = sha(dependency)
if not dependencies: raise RuntimeError('no actual compiler dependency files')
artifact_paths = [build/'probe83', build/'ros_probe83', build/'CMakeCache.txt']
artifact_paths += sorted(build.rglob('flags.make')) + sorted(build.rglob('link.txt'))
receipt = dict(initial, status='COMPLETE', verification_after='COMPLETE',
               source_sha256=plan['source_sha256'],
               artifact_sha256={str(p):sha(p) for p in artifact_paths},
               observed_compiler_dependency_sha256=dependencies,
               dependency_scope='compiler depfiles observed after build; not a presealed SDK closure')
with (build/'build_receipt.json').open('x') as f:
    json.dump(receipt, f, indent=2, sort_keys=True)
    f.write('\n'); f.flush(); os.fsync(f.fileno())
print(json.dumps({'status':'COMPLETE','build':str(build),'actual_actor_calls':0}))
PY
