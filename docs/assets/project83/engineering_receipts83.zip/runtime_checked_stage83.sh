#!/usr/bin/env bash
set -eo pipefail
rtk proxy /usr/bin/python3 -B -m pytest --noconftest tests/test_cli83.py -q
rtk proxy /bin/bash /home/lyh/project83_work_20261104/build_checked83.sh
source /opt/ros/humble/setup.bash
rtk proxy /usr/bin/python3 -B /home/lyh/project83_work_20261104/cold_ros_checked83.py
